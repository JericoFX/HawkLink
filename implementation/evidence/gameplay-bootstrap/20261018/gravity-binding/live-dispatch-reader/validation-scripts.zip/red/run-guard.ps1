param([ValidateSet('red','green')][string]$Phase,[int]$DeadlineSeconds=90,[long]$MaxOwnedWorkingSet=2147483648)
$ErrorActionPreference='Stop'
$root='F:\HawkenServer'
$outDir=Join-Path $root 'implementation\evidence\gameplay-bootstrap\20261018\gravity-binding\live-dispatch-reader\red'
function Ram { $o=Get-CimInstance Win32_OperatingSystem; [ordered]@{utc=[DateTime]::UtcNow.ToString('o');usedPercent=100.0*(1-$o.FreePhysicalMemory/$o.TotalVisibleMemorySize);freeBytes=[int64]$o.FreePhysicalMemory*1KB} }
$before=Ram
$before | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $outDir 'admission.json') -Encoding utf8
if($before.usedPercent -ge 70 -or $before.freeBytes -lt 10GB){throw 'Component validation admission failed'}
$busy=@(Get-CimInstance Win32_Process | Where-Object Name -In @('java.exe','cmake.exe','ninja.exe','cl.exe','link.exe','ctest.exe'))
if($busy.Count){throw 'Incompatible work is already running'}
$handles=@{}; $samples=[Collections.Generic.List[object]]::new(); $guard=$false; $timedOut=$false
$proc=$null
try {
    $wrapper=Join-Path $outDir ('run-'+$Phase+'.cmd')
    $proc=Start-Process -FilePath $env:ComSpec -ArgumentList ('/d /c "'+$wrapper+'"') -WorkingDirectory $root -WindowStyle Hidden -PassThru
    $creation=$proc.StartTime.ToUniversalTime()
    $handles[$proc.Id]=[pscustomobject]@{handle=$proc;creation=$creation;path=$proc.MainModule.FileName;depth=0}
    $limit=[DateTime]::UtcNow.AddSeconds($DeadlineSeconds)
    do {
        $all=@(Get-CimInstance Win32_Process)
        for($level=0;$level -lt 6;$level++) {
            foreach($row in $all) {
                if($handles.ContainsKey([int]$row.ProcessId) -or -not $handles.ContainsKey([int]$row.ParentProcessId)){continue}
                $parent=$handles[[int]$row.ParentProcessId]
                if($parent.handle.HasExited -or -not $row.CreationDate -or $row.CreationDate.ToUniversalTime() -lt $parent.creation){continue}
                $h=Get-Process -Id $row.ProcessId -ErrorAction SilentlyContinue
                if(-not $h){continue}
                if($h.HasExited -or [math]::Abs(($h.StartTime.ToUniversalTime()-$row.CreationDate.ToUniversalTime()).TotalSeconds) -gt 1 -or $h.MainModule.FileName -ine $row.ExecutablePath){$h.Dispose();continue}
                $h.PriorityClass='BelowNormal'
                $handles[$h.Id]=[pscustomobject]@{handle=$h;creation=$h.StartTime.ToUniversalTime();path=$h.MainModule.FileName;depth=$parent.depth+1}
            }
        }
        $sample=Ram; $sample.ownedWorkingSet=(@($handles.Values | Where-Object {-not $_.handle.HasExited} | ForEach-Object {$_.handle.Refresh();$_.handle.WorkingSet64}) | Measure-Object -Sum).Sum; $samples.Add($sample)
        $guard=$sample.usedPercent -ge 80 -or $sample.ownedWorkingSet -gt $MaxOwnedWorkingSet; $timedOut=[DateTime]::UtcNow -ge $limit
        if($guard -or $timedOut){break}
    } while(-not $proc.WaitForExit(2000))
    if(-not $proc.HasExited -and -not $guard -and -not $timedOut){throw 'Launcher state unavailable'}
} finally {
    # Retain each verified process handle independently: cleanup still works if
    # the launcher exited first. Never require a live parent to clean its child.
    $closed=@()
    foreach($node in @($handles.Values | Sort-Object depth -Descending)) {
        $h=$node.handle
        try {
            if(-not $h.HasExited) {
                $check=Get-CimInstance Win32_Process -Filter "ProcessId = $($h.Id)" -ErrorAction SilentlyContinue
                if($check -and [math]::Abs(($check.CreationDate.ToUniversalTime()-$node.creation).TotalSeconds) -lt 1 -and $check.ExecutablePath -ieq $node.path){$h.Kill();[void]$h.WaitForExit(5000)}
            }
            $closed+=@{pid=$h.Id;creationUtc=$node.creation.ToString('o');path=$node.path;terminal=$h.HasExited;exit=if($h.HasExited){$h.ExitCode}else{$null}}
        } finally {if($h -ne $proc){$h.Dispose()}}
    }
    $result=[ordered]@{utc=[DateTime]::UtcNow.ToString('o');admission=$before;guardTriggered=$guard;deadlineTriggered=$timedOut;processes=$closed;samples=$samples.ToArray();launcherExit=if($proc -and $proc.HasExited){$proc.ExitCode}else{$null};finalRam=Ram}
    $result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $outDir 'component-run-result.json') -Encoding utf8
    if($proc){$proc.Dispose()}
}
if($guard -or $timedOut){exit 4}
if($result.launcherExit -ne 0){exit 1}



