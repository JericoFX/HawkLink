$ErrorActionPreference='Stop'
$outDir=Split-Path -Parent $MyInvocation.MyCommand.Path
$probe='F:\HawkenServer\build\windows-msvc\hawken-controller-netfields-probe.exe'
if(Get-CimInstance Win32_Process -Filter 'ProcessId=4294967295'){throw 'Fixture PID unexpectedly exists'}
$results=@()
$helpText=Get-Content -Raw -LiteralPath (Join-Path $outDir 'help.log')
$results+=@{name='help-lists-live-gravity';exit=0;containsLiveGravity=$helpText.Contains('--live-gravity');passed=$helpText.Contains('--live-gravity')}
foreach($case in @(
    @{name='live-gravity-unavailable';arguments=@('4294967295','--live-gravity');exit=1;error='process_unavailable'},
    @{name='live-player-unavailable';arguments=@('4294967295','--live-player');exit=1;error='process_unavailable'},
    @{name='live-fire-timing-unavailable';arguments=@('4294967295','--live-fire-timing');exit=1;error='process_unavailable'},
    @{name='live-gravity-invalid-pid';arguments=@('0','--live-gravity');exit=2;error='invalid_arguments'},
    @{name='unknown-mode';arguments=@('4294967295','--unknown-mode');exit=2;error='invalid_arguments'},
    @{name='gravity-mixed-with-fire-timing';arguments=@('4294967295','--live-gravity','--live-fire-timing');exit=2;error='invalid_arguments'},
    @{name='gravity-mixed-with-player';arguments=@('4294967295','--live-gravity','--live-player');exit=2;error='invalid_arguments'}
)) {
    $arguments=$case.arguments
    $raw=@(& $probe @arguments)
    $nativeExit=$LASTEXITCODE
    $raw | Set-Content -LiteralPath (Join-Path $outDir ($case.name+'.log')) -Encoding utf8
    $json=($raw -join "`n") | ConvertFrom-Json
    $passed=$nativeExit -eq $case.exit -and $json.status -eq 'inconclusive' -and $json.error -eq $case.error -and $json.identity_verified -eq $false
    $results+=@{name=$case.name;exit=$nativeExit;error=$json.error;passed=$passed}
}
$results | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $outDir 'cli-results.json') -Encoding utf8
if(@($results | Where-Object {-not $_.passed}).Count){exit 1}
exit 0

