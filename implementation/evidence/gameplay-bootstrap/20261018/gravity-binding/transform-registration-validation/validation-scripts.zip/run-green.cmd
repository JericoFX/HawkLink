@echo off
setlocal
cd /d "F:\HawkenServer"
"C:\Users\Jerico\AppData\Local\Programs\Python\Python314\python.exe" -B "F:\HawkenServer\implementation\evidence\gameplay-bootstrap\20261018\controller-possession\world-collision-readiness\export-closure\property-refs\transform-collision-context\find-transform-registrations.py" > "F:\HawkenServer\implementation\evidence\gameplay-bootstrap\20261018\gravity-binding\transform-registration-validation\registration.stdout.log" 2> "F:\HawkenServer\implementation\evidence\gameplay-bootstrap\20261018\gravity-binding\transform-registration-validation\registration.stderr.log"
set "registrationExit=%errorlevel%"
> "F:\HawkenServer\implementation\evidence\gameplay-bootstrap\20261018\gravity-binding\transform-registration-validation\registration.exit" echo %registrationExit%
exit /b %registrationExit%
